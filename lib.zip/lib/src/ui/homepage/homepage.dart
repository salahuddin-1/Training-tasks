import 'package:flutter/material.dart';
import 'package:neosoft_training_tasks/src/ui/Training_task_1/list_using_network_call.dart';
import 'package:neosoft_training_tasks/src/ui/Training_task_2/forms.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return TaskForms();
  }
}
