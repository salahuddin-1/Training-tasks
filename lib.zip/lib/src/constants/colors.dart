import 'package:flutter/material.dart';

const CYAN = const Color(0xff0097a7);

const White = const Color(0xffffffff);
