import 'package:flutter/material.dart';
import 'package:neosoft_training_tasks/src/constants/colors.dart';

import 'src/ui/homepage/homepage.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NeoSOFT Training Tasks',
      debugShowCheckedModeBanner: false,
      theme: _ThemeDataCustom()._themeData(context),
      home: HomePage(),
    );
  }
}

class _ThemeDataCustom {
  ThemeData _themeData(BuildContext context) {
    return ThemeData(
      primaryColor: White,
      accentColor: White,
      scaffoldBackgroundColor: White,
      buttonColor: CYAN,
      appBarTheme: _appbarTheme(),
      textSelectionTheme: _cusrsorTheme(),
    );
  }

  TextSelectionThemeData _cusrsorTheme() {
    return TextSelectionThemeData(
      cursorColor: Colors.black,
    );
  }

  AppBarTheme _appbarTheme() {
    return AppBarTheme(
      centerTitle: true,
      textTheme: TextTheme(
        headline6: TextStyle(
          color: CYAN,
          fontSize: 18,
        ),
      ),
    );
  }
}
